<?php
$pid = $_GET["pid"];
?>

<?php
function get_image_url($pid) {
    // 連線 MySQL 資料庫
    $servername = "localhost";
    $username = "api";
    $password = "ApqowiePI";
    $dbname = "dbAPI";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    // 取得上傳影像 PID
    $sql = "SELECT img, thm FROM image2cis WHERE pid='$pid';";
    // echo "SQL = ".$sql."<br>";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        // 查詢成功
        // echo "查詢成功（取得影像名稱，img）<br>";
    } else {
        // 查詢失敗，可以進一步處理錯誤
        echo "錯誤: " . mysqli_error($conn);
    }
    $row = mysqli_fetch_assoc($result);
    $img = $row["img"];
    $thm = $row["thm"];
    // echo "YES, img = $img<br>";
    // echo "YES, thm = $thm<br>";
    // 關閉資料庫連線
    mysqli_close($conn);
    $img_url = "https://etech.gac.ntnu.edu.tw/v/$img";
    $ret = array($img_url, $thm);
    return $ret;
}

$ret = get_image_url($pid);
$src = $ret[0];
$thm = $ret[1];
// echo "src = $src<br>";
// echo "thm = $thm<br>";
?>

<?php
if ($thm != "ERROR") {
    $pack = json_decode($thm, true);
    $colors = $pack["color"];
    $theme = "";
    $url_template = "template.php?";
    for ($i = 0; $i < count($colors); $i++) {
        $rgb = $colors[$i];
        $theme = $theme . "<div class=\"checker\" style=\"background-color:$rgb\"></div>";
        $url_template = $url_template . "c" . ($i+1) . "=" . substr($rgb, 1) . "&";
    }
    $clst = $pack["cis"];
    $imagery = "";
    for ($i = 0; $i < count($clst); $i++) {
        $im = $clst[$i];
        $imagery = $imagery . " $im";
    }
} else {
    // $theme = "";
    // for ($i = 0; $i < 10; $i++) {
    //     $rgb = "lightgray";
    //     $theme = $theme . "<div class=\"checker\" style=\"background-color:$rgb\"></div>";
    // }
    $theme = "<span>（ERROR）</span>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>API</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
</head>

<style>
    .jumbotron {
        color: navy;
        background-color: lightblue;
        padding: 20px;
    }
    #status {
        position: relative;
        margin: 0px auto;
        width: 480px;
        height: 170px;
    }
    #preview {
        position: absolute;
        width: 120px;
        height: 120px;
        left: 20px;
        top: 20px;
    }
    #theme {
        position: absolute;
        width: 160px;
        height: 40px;
        left: 160px;
        top: 40px;
    }
    #imagery {
        position: absolute;
        width: 220px;
        height: 50px;
        left: 160px;
        top: 80px;
    }
    .checker {
        float: left;
        display: block;
        width: 30px;
        height: 30px;
    }
    #template {
        display: block;
        margin: 0px auto;
        width: 200px;
        height: 200px;
    }
</style>

<script>
    function browse_images() {
        location.href = "https://etech.gac.ntnu.edu.tw/v";
    }
    function browse_dbAPI() {
        location.href = "https://etech.gac.ntnu.edu.tw/phpmyadmin";
    }
    function more_image() {
        location.href = "edu_upload.html";
    }
</script>

<body>
    <div class="jumbotron text-center" >
        <h3>
            <span style="color:red">Color</span>
            <span style="color:limegreen">Theme</span>
            <span style="color:orange">Result</span>
        </h3>
        powered by <b>image2cis</b> API
    </div>
    <div class="container">
        <div id="status">
            <div id="preview">
                <img src="<?php echo $src; ?>" width="90%" class="img-thumbnail">
            </div>
            <div id="theme">
                <?php echo $theme; ?><br>
            </div>
            <div id="imagery">
                <?php echo $imagery; ?>
            </div>
        </div>
        配色範例：
        <iframe id="template" src="<?php echo $url_template; ?>">
            <!-- <img src="template.svg" width="40%" class="img-thumbnail"> -->
        </iframe>
        <div style="text-align:center;margin-top:20px;">
            <!-- <input type="button" class="btn btn-success" value="影像庫" onclick="browse_images()">
            <input type="button" class="btn btn-success" value="資料庫" onclick="browse_dbAPI()"> -->
            <input type="button" class="btn btn-primary" value="再測試" onclick="more_image()">
        </div>
    </div>
</body>

</html>
