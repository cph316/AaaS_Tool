<?php
function get_image_pid($txt) {
    // 連線 MySQL 資料庫
    $servername = "localhost";
    $username = "api";
    $password = "ApqowiePI";
    $dbname = "dbAPI";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    // 取得上傳影像 PID
    $sql = "CALL get_cis_image_token('$txt');";
    // echo "SQL = ".$sql."<br>";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        // 查詢成功
        echo "查詢成功（取得號碼牌，PID）<br>";
    } else {
        // 查詢失敗，可以進一步處理錯誤
        echo "錯誤: " . mysqli_error($conn);
    }
    $row = mysqli_fetch_assoc($result);
    $pid = $row["pic_id"];
    // echo "YES, pid = $pid<br>";
    // 關閉資料庫連線
    mysqli_close($conn);
    return $pid;
}
function set_image_name($pid, $pname) {
    // 連線 MySQL 資料庫
    $servername = "localhost";
    $username = "api";
    $password = "ApqowiePI";
    $dbname = "dbAPI";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    // 取得上傳影像 PID
    $sql = "CALL set_cis_image_name($pid, '$pname');";
    // echo "SQL = ".$sql."<br>";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        // 查詢成功
        echo "查詢成功（註冊影像檔名稱）<br>";
    } else {
        // 查詢失敗，可以進一步處理錯誤
        echo "錯誤: " . mysqli_error($conn);
    }
    // 關閉資料庫連線
    mysqli_close($conn);
    return $pid;
}
?>

<?php
// 取得上傳資料
$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

echo "fname = " . $_FILES["image"]["name"] . "<br>";
echo "target_file   = $target_file <br>";
echo "imageFileType = $imageFileType <br>";
?>

<?php
// 檢查文件是否是影像
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false) {
        echo "檔案是一個影像 - " . $check["mime"] . ".<br>";
        $uploadOk = 1;
    } else {
        echo "檔案不是影像。<br>";
        $uploadOk = 0;
    }
}

// // 檢查文件是否已存在
// if (file_exists($target_file)) {
//     echo "很抱歉，檔案已存在。<br>";
//     $uploadOk = 0;
// }

// 檢查文件大小
if ($_FILES["image"]["size"] > 1024*1024*8) {
    echo "很抱歉，您的檔案太大。<br>";
    $uploadOk = 0;
}

// 允許特定的文件格式
if ($imageFileType != "jpg" && $imageFileType != "JPG" &&
    $imageFileType != "png" && $imageFileType != "PNG" &&
    $imageFileType != "jpeg" && $imageFileType != "JPEG" &&
    $imageFileType != "gif" && $imageFileType != "GIF") {
// if ($imageFileType != "jpg") {
    echo "很抱歉，只允許 JPG, JPEG, PNG & GIF 格式的檔案。";
    // echo "很抱歉，只允許 JPG 格式的檔案。<br>";
    $uploadOk = 0;
}
?>

<?php
$txt = $_POST["txt"];
echo "txt = " . $txt . "<br>";
?>

<?php
$pid = get_image_pid($txt);
echo "pid = " . $pid . "<br>";
$pname = sprintf("p%06d.%s", $pid, $imageFileType);
echo "pname = " . $pname . "<br>";
?>

<?php
// 檢查 $uploadOk 是否被設為 0 
if ($uploadOk == 0) {
    echo "很抱歉，您的檔案未被上傳。<br>";
} else {
    // 真實影像儲存動作
    $target_file = $target_dir . $pname;
    echo "target file = " . $target_file . "<br>";
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        echo "檔案名稱 ". basename( $_FILES["image"]["name"]). " 已被上傳。<br>";
    } else {
        echo "很抱歉，上傳您的檔案時出現了一個錯誤。<br>";
        $uploadOk = 0;
    }
}
?>

<?php
// 確認上傳成功
if ($uploadOk == 1) {
    set_image_name($pid, $pname);
    echo "上傳程序完整完成！<br>";
}
?>

<?php
// 轉移至下一頁
if ($uploadOk == 0) {
    $url = "edu_upload.html";
    echo "上傳影像：$url<br>";
} else {
    $url = "edu_view.php?pid=$pid";
    echo "觀看結果：$url<br>";
}
?>

<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API</title>
 </head>
 <script>
    let s = 5;
    function countdown() {
        s = s - 1;
        document.getElementById("sec").innerHTML = s.toString();
        if (s <= 0) {
            location.href = "<?php echo $url; ?>";
        }
    }
    setInterval(countdown, 1000);
 </script>
 <body>
    <h1 align="center"><span id="sec" style="color:crimson">5</span> 秒後自動關閉。</h1>
 </body>
 </html>